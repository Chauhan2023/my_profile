export const information = {
  personal_information: {
    first_name: "Rohit",
    last_name: "Chauhan",
    location: "South Delhi, India",
    email: "rohitchauhan19780@gmail.com",
    linkedin: "linkedin.com/in/contact-rohit",
    phone: "+91-8368055013",
  },
  socials: [
    {
      name: "LinkedIn",
      url: "https://linkedin.com/in/contact-rohit",
    },
    {
      name: "GitHub",
      url: "https://github.com/Chauhan2023",
    },
  ],
  technical_skills: {
    frontend:
      "React.js, React Native, JavaScript, Redux, HTML, CSS, Tailwind CSS, Next.js",
    backend: "Node.js, Express.js, Fastify, WebSockets, Redis",
    database: "MySQL",
    deployment: "VPS Hosting, Nginx, PM2, Cloudflare, SSH",
  },
  skills: [
    {
      name: "React.js",
      icon: "/images/home/education-skill/React.png",
      rating: 5,
    },
    {
      name: "Next.js",
      icon: "/images/home/education-skill/Next.js.png",
      rating: 5,
    },
    {
      name: "JavaScript",
      icon: "/images/home/education-skill/JavaScript.png",
      rating: 5,
    },
    {
      name: "Node.js",
      icon: "/images/home/education-skill/Node.js.png",
      rating: 4,
    },
    {
      name: "Express.js",
      icon: "/images/home/education-skill/Express.png",
      rating: 4,
    },

    {
      name: "MySQL",
      icon: "/images/home/education-skill/MySQL.png",
      rating: 3,
    },
  ],
  experience: [
    {
      company: "Digital Gourmet",
      role: "Executive Full Stack Developer",
      duration: "Dec 2024- Present",
      location: "Gurugram, Haryana",
      responsibilities: [
        "Built full-stack MERN applications with secure APIs and responsive UI.",
        "Developed React Native mobile apps with real-time features and payment integration.",
      ],
    },
    {
      company: "Probey Services",
      role: "Intern Full Stack Developer",
      duration: "Apr 2024-Dec 2024",
      location: "Noida, Uttar Pradesh",
      responsibilities: [
        "Built and styled admin dashboards and client-facing UIs using React.js.",
      ],
    },
  ],
  projects: [
    {
      name: "Psolvi - Health & Wellness (React Native)",
      links: ["github.com/Chauhan2023", "https://www.psolvi.com"],
      description: [
        "Developed a preventive wellness mobile application with secure audio/video doctor consultations.",
        "Implemented mood tracking, habit tracking, podcasts, wellness games, and educational video modules.",
        "Built e-commerce module for wellness product booking and integrated clinic management features.",
        "Designed scalable backend APIs and optimised app performance for real-time user interactions.",
      ],
    },
    {
      name: "Pro Health",
      links: ["https://healthcare.projects-digitalgourmet.in/"],
      description: [
        "Built a healthcare platform enabling doctor onboarding, appointment scheduling, and patient consultations.",
        "Integrated payment gateway and real-time audio/video consultation functionality.",
        "Developed an admin dashboard using React and Next.js for managing users, doctors, and schedules.",
      ],
    },
    {
      name: "Aikyam Sport Club",
      links: ["https://aikyamriseclub.com/"],
      description: [
        "Developed a sports club management system for memberships, ground bookings, and event scheduling.",
        "Implemented team management features, including player roles, announcements, and match planning.",
        "Built secure role-based access control for admins, coaches, and members.",
      ],
    },
    {
      name: "Coaching Management System",
      links: ["http://education.projects-digitalgourmet.in/"],
      description: [
        "Built a coaching platform to manage batches, schedules, attendance, and faculty assignments.",
        "Implemented scalable frontend architecture using React Context API and reusable components.",
      ],
    },
  ],
  education: [
    {
      institution: "Guru Gobind Singh Indraprastha University",
      degree: "Bachelor of Technology (B. Tech)",
      year: "2020-2024",
      location: "New Delhi, India",
    },
    {
      institution: "Bharat Public School (CBSE)",
      degree: "Senior Secondary (PCM)",
      year: "2021",
      location: "New Delhi, India",
    },
  ],
};
